# PracticalWeb
-- https://edu.anarcho-copy.org/Programming%20Languages/Haskell/Practical%20Web%20Development%20with%20Haskell.pdf

# Usage
```
brew install pcre
stack test
stack run
```